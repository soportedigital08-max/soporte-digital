import Hero from "@/components/sections/Hero";
import Problemas from "@/components/sections/Problemas";

export default function HomePage() {
  return (
    <div className="container">
      <Hero />
      <Problemas />
    </div>
  );
}
