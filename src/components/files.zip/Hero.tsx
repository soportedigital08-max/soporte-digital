import Button from "@/components/ui/Button";

export default function Hero() {
  return (
    <section className="py-24 text-center">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-h1 text-gray-900">Tecnología que funciona.</h1>

        <p className="text-body-lg text-gray-600 mt-6">
          Resolvemos problemas reales de tecnología en tu casa, trabajo o negocio.
        </p>
      </div>

      <div className="mt-8">
        <Button href="/contacto" variant="primary">
          Solicitar soporte
        </Button>
      </div>
    </section>
  );
}
