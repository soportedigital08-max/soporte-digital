import Card from "@/components/ui/Card";

// Problemas y rutas — deben coincidir con los slugs de 03-ARQUITECTURA.md §4 Nivel 3
const PROBLEMAS = [
  {
    title: "Mi PC está lenta",
    description: "Diagnóstico y optimización para que tu equipo vuelva a rendir.",
    href: "/servicios/pc-lenta",
  },
  {
    title: "El WiFi no funciona bien",
    description: "Revisamos y mejoramos la señal y estabilidad de tu red.",
    href: "/servicios/wifi-lento",
  },
  {
    title: "Perdí archivos importantes",
    description: "Recuperación de datos perdidos o dañados.",
    href: "/servicios/recuperacion-de-datos",
  },
  {
    title: "Necesito una página web",
    description: "Creamos tu sitio web a medida.",
    href: "/servicios/crear-pagina-web",
  },
];

export default function Problemas() {
  return (
    <section className="py-24">
      <h2 className="text-h2 text-gray-900 text-center">
        ¿Qué problema estás teniendo?
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mt-12">
        {PROBLEMAS.map((problema) => (
          <Card
            key={problema.href}
            title={problema.title}
            description={problema.description}
            href={problema.href}
          />
        ))}
      </div>
    </section>
  );
}
